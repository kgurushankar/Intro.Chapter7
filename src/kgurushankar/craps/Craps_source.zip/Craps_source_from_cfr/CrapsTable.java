/*
 * Decompiled with CFR 0_118.
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class CrapsTable
extends JPanel
implements ActionListener {
    private RollingDie die1;
    private RollingDie die2;
    private final int delay = 20;
    private Timer clock;
    private CrapsGame game;
    private DisplayPanel display;

    public CrapsTable(DisplayPanel displayPanel) {
        this.setBackground(Color.green);
        this.setBorder(new LineBorder(Color.ORANGE.darker(), 3));
        this.display = displayPanel;
        this.game = new CrapsGame();
        this.die1 = new RollingDie();
        this.die2 = new RollingDie();
        this.clock = new Timer(20, this);
    }

    public void rollDice() {
        RollingDie.setBounds(3, this.getWidth() - 3, 3, this.getHeight() - 3);
        this.die1.roll();
        this.die2.roll();
        this.clock.start();
    }

    public void actionPerformed(ActionEvent actionEvent) {
        if (this.diceAreRolling()) {
            if (!this.clock.isRunning()) {
                this.clock.restart();
            }
            if (this.die1.isRolling()) {
                this.die1.avoidCollision(this.die2);
            } else if (this.die2.isRolling()) {
                this.die2.avoidCollision(this.die1);
            }
        } else {
            this.clock.stop();
            int n = this.die1.getNumDots() + this.die2.getNumDots();
            int n2 = this.game.processRoll(n);
            int n3 = this.game.getPoint();
            this.display.update(n2, n3);
        }
        this.repaint();
    }

    public boolean diceAreRolling() {
        return this.die1.isRolling() || this.die2.isRolling();
    }

    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        this.die1.draw(graphics);
        this.die2.draw(graphics);
    }
}

