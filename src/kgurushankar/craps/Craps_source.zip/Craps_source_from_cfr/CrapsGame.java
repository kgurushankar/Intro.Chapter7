/*
 * Decompiled with CFR 0_118.
 */
public class CrapsGame {
    private int point = 0;

    public int processRoll(int n) {
        int n2;
        if (this.point == 0) {
            if (n == 7 || n == 11) {
                n2 = 1;
            } else if (n == 2 || n == 3 || n == 12) {
                n2 = -1;
            } else {
                n2 = 0;
                this.point = n;
            }
        } else if (n == this.point) {
            n2 = 1;
            this.point = 0;
        } else if (n == 7) {
            n2 = -1;
            this.point = 0;
        } else {
            n2 = 0;
        }
        return n2;
    }

    public int getPoint() {
        return this.point;
    }
}

