/*
 * Decompiled with CFR 0_118.
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class DisplayPanel
extends JPanel {
    private JTextField wonText;
    private JTextField lostText;
    private JTextField pointText;
    private int wonCount;
    private int lostCount;

    public DisplayPanel() {
        super(new GridLayout(2, 3, 10, 0));
        this.setBorder(new EmptyBorder(0, 0, 5, 0));
        this.add(new JLabel("    Won:"));
        this.add(new JLabel("    Lost:"));
        this.add(new JLabel("    Point:"));
        Font font = new Font("Monospaced", 1, 16);
        this.wonText = new JTextField("  0", 5);
        this.wonText.setFont(font);
        this.wonText.setEditable(false);
        this.wonText.setBackground(Color.WHITE);
        this.add(this.wonText);
        this.lostText = new JTextField("  0", 5);
        this.lostText.setFont(font);
        this.lostText.setEditable(false);
        this.lostText.setBackground(Color.WHITE);
        this.add(this.lostText);
        this.pointText = new JTextField(5);
        this.pointText.setFont(font);
        this.pointText.setEditable(false);
        this.pointText.setBackground(Color.DARK_GRAY);
        this.add(this.pointText);
    }

    public void update(int n, int n2) {
        if (n > 0) {
            ++this.wonCount;
            this.wonText.setText("  " + this.wonCount);
            this.pointText.setText("");
            this.pointText.setBackground(Color.DARK_GRAY);
        } else if (n < 0) {
            ++this.lostCount;
            this.lostText.setText("  " + this.lostCount);
            this.pointText.setText("");
            this.pointText.setBackground(Color.DARK_GRAY);
        } else {
            this.pointText.setText("  " + n2);
            this.pointText.setBackground(Color.YELLOW);
        }
    }
}

