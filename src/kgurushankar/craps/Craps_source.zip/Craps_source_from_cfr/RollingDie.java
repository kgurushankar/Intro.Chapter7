/*
 * Decompiled with CFR 0_118.
 */
import java.awt.Color;
import java.awt.Graphics;

public class RollingDie
extends Die {
    private static final double slowdown = 0.97;
    private static final double speedFactor = 0.04;
    private static final double speedLimit = 2.0;
    private static int tableLeft;
    private static int tableRight;
    private static int tableTop;
    private static int tableBottom;
    private final int dieSize = 24;
    private int xCenter = -1;
    private int yCenter = -1;
    private double xSpeed;
    private double ySpeed;

    public static void setBounds(int n, int n2, int n3, int n4) {
        tableLeft = n;
        tableRight = n2;
        tableTop = n3;
        tableBottom = n4;
    }

    public void roll() {
        super.roll();
        int n = tableRight - tableLeft;
        int n2 = tableBottom - tableTop;
        this.xCenter = tableLeft;
        this.yCenter = tableTop + n2 / 2;
        this.xSpeed = (double)n * (Math.random() + 1.0) * 0.04;
        this.ySpeed = (double)n2 * (Math.random() - 0.5) * 2.0 * 0.04;
    }

    public boolean isRolling() {
        return this.xSpeed > 2.0 || this.xSpeed < -2.0 || this.ySpeed > 2.0 || this.ySpeed < -2.0;
    }

    public void avoidCollision(RollingDie rollingDie) {
        if (rollingDie == this) {
            return;
        }
        while (Math.abs(this.xCenter - rollingDie.xCenter) < 24 && Math.abs(this.yCenter - rollingDie.yCenter) < 24) {
            this.move();
        }
    }

    private void move() {
        this.xCenter = (int)((double)this.xCenter + this.xSpeed);
        this.yCenter = (int)((double)this.yCenter + this.ySpeed);
        int n = 12;
        if (this.xCenter < tableLeft + n) {
            this.xCenter = tableLeft + n;
            this.xSpeed = - this.xSpeed;
        }
        if (this.xCenter > tableRight - n) {
            this.xCenter = tableRight - n;
            this.xSpeed = - this.xSpeed;
        }
        if (this.yCenter < tableTop + n) {
            this.yCenter = tableTop + n;
            this.ySpeed = - this.ySpeed;
        }
        if (this.yCenter > tableBottom - n) {
            this.yCenter = tableBottom - n;
            this.ySpeed = - this.ySpeed;
        }
    }

    public void draw(Graphics graphics) {
        if (this.xCenter < 0 || this.yCenter < 0) {
            return;
        }
        if (this.isRolling()) {
            this.move();
            this.drawRolling(graphics);
            this.xSpeed *= 0.97;
            this.ySpeed *= 0.97;
        } else {
            this.drawStopped(graphics);
        }
    }

    private void drawRolling(Graphics graphics) {
        int n = this.xCenter - 12 + (int)(3.0 * Math.random()) - 1;
        int n2 = this.yCenter - 12 + (int)(3.0 * Math.random()) - 1;
        graphics.setColor(Color.RED);
        if (n % 2 != 0) {
            graphics.fillRoundRect(n, n2, 24, 24, 6, 6);
        } else {
            graphics.fillOval(n - 2, n2 - 2, 28, 28);
        }
        Die die = new Die();
        die.roll();
        this.drawDots(graphics, n, n2, die.getNumDots());
    }

    private void drawStopped(Graphics graphics) {
        int n = this.xCenter - 12;
        int n2 = this.yCenter - 12;
        graphics.setColor(Color.RED);
        graphics.fillRoundRect(n, n2, 24, 24, 6, 6);
        this.drawDots(graphics, n, n2, this.getNumDots());
    }

    private void drawDots(Graphics graphics, int n, int n2, int n3) {
        graphics.setColor(Color.WHITE);
        int n4 = 6;
        int n5 = 3;
        int n6 = n + n5 - 1;
        int n7 = n + 3 * n5;
        int n8 = n + 5 * n5 + 1;
        int n9 = n2 + n5 - 1;
        int n10 = n2 + 3 * n5;
        int n11 = n2 + 5 * n5 + 1;
        switch (n3) {
            case 1: {
                graphics.fillOval(n7, n10, n4, n4);
                break;
            }
            case 2: {
                graphics.fillOval(n6, n9, n4, n4);
                graphics.fillOval(n8, n11, n4, n4);
                break;
            }
            case 3: {
                graphics.fillOval(n6, n9, n4, n4);
                graphics.fillOval(n7, n10, n4, n4);
                graphics.fillOval(n8, n11, n4, n4);
                break;
            }
            case 4: {
                graphics.fillOval(n6, n9, n4, n4);
                graphics.fillOval(n8, n9, n4, n4);
                graphics.fillOval(n6, n11, n4, n4);
                graphics.fillOval(n8, n11, n4, n4);
                break;
            }
            case 5: {
                graphics.fillOval(n6, n9, n4, n4);
                graphics.fillOval(n8, n9, n4, n4);
                graphics.fillOval(n7, n10, n4, n4);
                graphics.fillOval(n6, n11, n4, n4);
                graphics.fillOval(n8, n11, n4, n4);
                graphics.fillOval(n7, n10, n4, n4);
                break;
            }
            case 6: {
                graphics.fillOval(n6, n9, n4, n4);
                graphics.fillOval(n6, n10, n4, n4);
                graphics.fillOval(n6, n11, n4, n4);
                graphics.fillOval(n8, n9, n4, n4);
                graphics.fillOval(n8, n10, n4, n4);
                graphics.fillOval(n8, n11, n4, n4);
            }
        }
    }
}

