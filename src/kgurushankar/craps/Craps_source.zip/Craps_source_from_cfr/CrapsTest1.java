/*
 * Decompiled with CFR 0_118.
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class CrapsTest1
extends JFrame
implements ActionListener {
    private CrapsGame game;
    private JTextField input;
    private JTextArea display;

    public CrapsTest1() {
        super("Craps: Test 1");
        Container container = this.getContentPane();
        container.setLayout(new FlowLayout());
        container.add(new JLabel("Next roll:"));
        this.input = new JTextField(5);
        this.input.setBackground(Color.YELLOW);
        this.input.addActionListener(this);
        container.add(this.input);
        this.display = new JTextArea(10, 20);
        this.display.setEditable(false);
        this.display.setBackground(Color.WHITE);
        container.add(new JScrollPane(this.display, 22, 31));
        this.game = new CrapsGame();
    }

    public void actionPerformed(ActionEvent actionEvent) {
        String string = this.input.getText().trim();
        int n = Integer.parseInt(string);
        int n2 = this.game.processRoll(n);
        int n3 = this.game.getPoint();
        this.input.setText("");
        this.display.append("" + n + ":  Result = " + n2 + " Point = " + n3 + "\n");
    }

    public static void main(String[] arrstring) {
        CrapsTest1 crapsTest1 = new CrapsTest1();
        crapsTest1.setBounds(100, 100, 300, 240);
        crapsTest1.setDefaultCloseOperation(3);
        crapsTest1.setResizable(false);
        crapsTest1.setVisible(true);
    }
}

