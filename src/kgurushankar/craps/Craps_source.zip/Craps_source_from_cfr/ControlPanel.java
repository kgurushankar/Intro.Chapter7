/*
 * Decompiled with CFR 0_118.
 */
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

public class ControlPanel
extends JPanel
implements ActionListener {
    private CrapsTable table;

    public ControlPanel(CrapsTable crapsTable) {
        this.table = crapsTable;
        JButton jButton = new JButton("Roll");
        jButton.addActionListener(this);
        this.add(jButton);
    }

    public void actionPerformed(ActionEvent actionEvent) {
        if (!this.table.diceAreRolling()) {
            this.table.rollDice();
        }
    }
}

