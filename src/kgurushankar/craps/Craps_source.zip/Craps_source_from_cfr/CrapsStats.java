/*
 * Decompiled with CFR 0_118.
 */
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class CrapsStats
extends JFrame
implements ActionListener {
    private CrapsGame game;
    private JTextField numberIn;
    private JTextField statsOut;

    public CrapsStats() {
        super("Craps test");
        Container container = this.getContentPane();
        container.setLayout(new FlowLayout());
        container.add(new JLabel("Number of games to run:"));
        this.numberIn = new JTextField(5);
        this.numberIn.addActionListener(this);
        container.add(this.numberIn);
        this.statsOut = new JTextField(18);
        this.statsOut.setEditable(false);
        container.add(this.statsOut);
        this.game = new CrapsGame();
    }

    public void actionPerformed(ActionEvent actionEvent) {
        String string = this.numberIn.getText();
        int n = Integer.parseInt(string);
        int n2 = 0;
        int n3 = 0;
        Die die = new Die();
        Die die2 = new Die();
        while (n2 < n) {
            die.roll();
            die2.roll();
            int n4 = die.getNumDots() + die2.getNumDots();
            int n5 = this.game.processRoll(n4);
            if (n5 != 0) {
                ++n2;
            }
            if (n5 <= 0) continue;
            ++n3;
        }
        this.numberIn.setText("");
        this.statsOut.setText(" Games: " + n2 + " Wins: " + n3);
    }

    public static void main(String[] arrstring) {
        CrapsStats crapsStats = new CrapsStats();
        crapsStats.setBounds(100, 100, 300, 100);
        crapsStats.setDefaultCloseOperation(3);
        crapsStats.setResizable(false);
        crapsStats.setVisible(true);
    }
}

