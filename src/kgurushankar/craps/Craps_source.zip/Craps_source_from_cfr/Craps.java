/*
 * Decompiled with CFR 0_118.
 */
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.LayoutManager;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class Craps
extends JFrame {
    public Craps() {
        super("Craps");
        DisplayPanel displayPanel = new DisplayPanel();
        CrapsTable crapsTable = new CrapsTable(displayPanel);
        ControlPanel controlPanel = new ControlPanel(crapsTable);
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BorderLayout());
        jPanel.setBorder(new EmptyBorder(0, 5, 0, 5));
        jPanel.add((Component)displayPanel, "North");
        jPanel.add((Component)crapsTable, "Center");
        jPanel.add((Component)controlPanel, "South");
        Container container = this.getContentPane();
        container.add((Component)jPanel, "Center");
    }

    public static void main(String[] arrstring) {
        Craps craps = new Craps();
        craps.setBounds(100, 100, 320, 240);
        craps.setDefaultCloseOperation(3);
        craps.setVisible(true);
    }
}

